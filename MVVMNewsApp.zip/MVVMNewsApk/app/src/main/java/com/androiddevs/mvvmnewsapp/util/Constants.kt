package com.androiddevs.mvvmnewsapp.util

class Constants {
    companion object {
        const val API_KEY = "207c98bd1db84cc7a1e7c0bd894ff29b"
        const val BASE_URL = "https://newsapi.org"
    }
}