package com.androiddevs.mvvmnewsapp.models

data class Source(
    val id: Any,
    val name: String
)